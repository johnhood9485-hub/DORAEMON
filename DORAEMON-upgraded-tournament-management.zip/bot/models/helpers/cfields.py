from typing import Any
from tortoise import fields
from enum import Enum

class ArrayField(fields.JSONField):
    """SQLite-compatible replacement for the original PostgreSQL array field.

    Values remain Python lists, and enum elements are converted using the
    original sub-field so Scrims/Tournament behaviour stays unchanged.
    """
    def __init__(self, field: fields.Field, **kwargs) -> None:
        self.sub_field = field
        super().__init__(**kwargs)

    def to_db_value(self, value: Any, instance: Any):
        if value is None:
            value = []
        converted = []
        for item in value:
            if isinstance(item, Enum):
                item = item.value
            try:
                item = self.sub_field.to_db_value(item, instance)
            except Exception:
                pass
            converted.append(item)
        return super().to_db_value(converted, instance)

    def to_python_value(self, value: Any) -> Any:
        value = super().to_python_value(value)
        if value is None:
            return []
        out = []
        for item in value:
            try:
                out.append(self.sub_field.to_python_value(item))
            except Exception:
                out.append(item)
        return out
