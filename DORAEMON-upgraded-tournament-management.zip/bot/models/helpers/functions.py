"""Compatibility exports for the old PostgreSQL array helpers.

SQLite builds update list fields in Python instead of emitting ARRAY_APPEND /
ARRAY_REMOVE SQL. These marker classes are retained so third-party imports do
not break.
"""
class ArrayAppend:
    def __init__(self, field, value): self.field, self.value = field, value
class ArrayRemove:
    def __init__(self, field, value): self.field, self.value = field, value
