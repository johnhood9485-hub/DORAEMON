"""Tiny .env loader with no third-party dependencies.

Supports simple KEY=VALUE lines, optional single/double quotes, and comments.
Existing environment variables always win.
"""
from __future__ import annotations

import os
from pathlib import Path


def load_env_file(path: str | Path) -> None:
    path = Path(path)
    if not path.is_file():
        return

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue

        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        elif " #" in value:
            value = value.split(" #", 1)[0].rstrip()

        os.environ.setdefault(key, value)
