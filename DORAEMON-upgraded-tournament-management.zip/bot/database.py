"""DORAEMON SQLite database bootstrap.

This build uses a local SQLite database so HeavenCloud does not need a
separate PostgreSQL service or port 5432.
"""
from __future__ import annotations

import logging
import os
from datetime import timedelta
from pathlib import Path

from tortoise import Tortoise

import config

logger = logging.getLogger(__name__)
_db_initialized = False

async def init_db(*, bot=None) -> None:
    global _db_initialized
    if _db_initialized:
        return
    await Tortoise.init(config=config.TORTOISE)
    await Tortoise.generate_schemas(safe=True)
    _db_initialized = True
    if bot is not None:
        await autofill_database(bot)
    logger.info("DORAEMON SQLite database initialized and autofilled: %s", config.DB_PATH)

async def autofill_database(bot) -> None:
    from models import Guild, User
    from models.misc.premium import PremiumPlan
    for guild in getattr(bot, "guilds", []):
        await Guild.get_or_create(guild_id=guild.id)
    for dev_id in getattr(bot, "config", None) and getattr(bot.config, "DEVS", []) or []:
        user, _ = await User.get_or_create(user_id=int(dev_id))
        if not user.is_dev:
            user.is_dev = True
            await user.save(update_fields=["is_dev"])
    if await PremiumPlan.all().count() == 0:
        await PremiumPlan.bulk_create([
            PremiumPlan(name="Trial (7d)", description="Duration: 7 days", price=29, duration=timedelta(days=7)),
            PremiumPlan(name="Basic (1m)", description="Duration: 28 days", price=79, duration=timedelta(days=28)),
            PremiumPlan(name="Professional (3m)", description="Duration: 84 days", price=229, duration=timedelta(days=84)),
            PremiumPlan(name="Enterprise (6m)", description="Duration: 168 days", price=469, duration=timedelta(days=168)),
            PremiumPlan(name="GodLike (Lifetime)", description="Duration: 69 years", price=4999, duration=timedelta(days=25185)),
        ])

async def ensure_user(user_id: int, *, is_dev: bool = False):
    from models import User
    user, _ = await User.get_or_create(user_id=int(user_id))
    if is_dev and not user.is_dev:
        user.is_dev = True
        await user.save(update_fields=["is_dev"])
    return user

async def ensure_guild(guild_id: int):
    from models import Guild
    guild, _ = await Guild.get_or_create(guild_id=int(guild_id))
    return guild

async def close_db() -> None:
    global _db_initialized
    if _db_initialized:
        await Tortoise.close_connections()
        _db_initialized = False
