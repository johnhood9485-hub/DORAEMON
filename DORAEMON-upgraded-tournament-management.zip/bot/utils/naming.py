"""Canonical Discord resource names for DORAEMON."""
import re

CHANNEL_PREFIX = "ᯓ⌬〢doraemon-"
ROLE_PREFIX = "❯❯❯❯══『 XT "
ROLE_SUFFIX = " •』"

CHANNEL_ALIASES = {
    # Legacy names are kept only as lookup aliases so existing guild resources migrate safely.
    "quotient-scrims-logs": "scrims-log",
    "quotient-tourney-logs": "scrims-log",
    "quotient-ultimate-logs": "ultimate-log",
    "doraemon-scrims-logs": "scrims-log",
    "doraemon-tourney-logs": "scrims-log",
    "doraemon-ultimate-logs": "ultimate-log",
    "tourney-slot-clam-cancel": "tourney-clam-cancel",
    "slot-clam-cancel": "slot-clam-cancel",
    "cancel-claim-slot": "slot-clam-cancel",
}

ROLE_ALIASES = {
    "scrims-mod": "scrims mod",
    "ultimate-mod": "ultimate mod",
    "tourney-mod": "tourney mod",
    "quotient-tag-ignore": "tag ignore",
    "doraemon-tag-ignore": "tag ignore",
    "tag-ignore": "tag ignore",
}

def bot_channel_name(name: str) -> str:
    """Return the standardized DORAEMON channel name for a legacy key."""
    name = str(name).strip()
    if name.startswith(CHANNEL_PREFIX):
        return name
    key = name.lower()
    name = CHANNEL_ALIASES.get(key, name)
    name = re.sub(r"[^a-zA-Z0-9-]+", "-", name)
    name = re.sub(r"-+", "-", name).strip("- ").lower()
    return CHANNEL_PREFIX + name

def bot_role_name(name: str) -> str:
    """Return the standardized XT role name for a legacy key."""
    name = str(name).strip()
    if name.startswith(ROLE_PREFIX) and name.endswith(ROLE_SUFFIX):
        return name
    key = name.lower()
    name = ROLE_ALIASES.get(key, name)
    name = re.sub(r"[-_]+", " ", name)
    name = re.sub(r"\s+", " ", name).strip(" •『』")
    return f"{ROLE_PREFIX}{name}{ROLE_SUFFIX}"


def tournament_channel_name(tournament_name: str, suffix: str) -> str:
    """Create a channel name using the admin-selected tournament name."""
    slug = re.sub(r"[^a-zA-Z0-9-]+", "-", str(tournament_name or "tournament").lower())
    slug = re.sub(r"-+", "-", slug).strip("-") or "tournament"
    suffix = re.sub(r"[^a-zA-Z0-9-]+", "-", str(suffix).lower()).strip("-")
    return f"ᯓ⌬〢{slug}-{suffix}"[:100]
