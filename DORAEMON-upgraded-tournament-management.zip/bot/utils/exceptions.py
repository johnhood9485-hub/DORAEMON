from discord.ext import commands


class DORAEMONError(commands.CheckFailure):
    pass


class NotSetup(DORAEMONError):
    def __init__(self):
        super().__init__(
            "This command requires you to have DORAEMON's private channel.\nKindly run `{ctx.prefix}setup` and try again."
        )


class NotPremiumGuild(DORAEMONError):
    def __init__(self):
        super().__init__(
            "This command requires this server to be premium.\n\nCheckout DORAEMON Premium [here]({ctx.bot.prime_link})"
        )


class NotPremiumUser(DORAEMONError):
    def __init__(self):
        super().__init__(
            "This command requires you to be a premium user.\nCheckout DORAEMON Premium [here]({ctx.bot.prime_link})"
        )


class InputError(DORAEMONError):
    pass


class SMNotUsable(DORAEMONError):
    def __init__(self):
        super().__init__("You need either the `scrims-mod` role or `Manage Server` permissions to use this command.")


class TMNotUsable(DORAEMONError):
    def __init__(self):
        super().__init__("You need either the `tourney-mod` role or `Manage Server` permissions to use tourney manager.")


class PastTime(DORAEMONError):
    def __init__(self):
        super().__init__(
            f"The time you entered seems to be in past.\n\nKindly try again, use times like: `tomorrow` , `friday 9pm`"
        )


TimeInPast = PastTime


class InvalidTime(DORAEMONError):
    def __init__(self):
        super().__init__(f"The time you entered seems to be invalid.\n\nKindly try again.")
