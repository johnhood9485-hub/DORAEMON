from __future__ import annotations

import asyncio
import typing

if typing.TYPE_CHECKING:
    from core import DORAEMON

from contextlib import suppress
from datetime import datetime, timedelta

import discord
from discord.ext import commands, tasks
from tortoise.expressions import Q

import config
from constants import random_greeting, random_thanks
from core import Cog, Context
from models import Guild, PremiumTxn, Timer, User
from utils import IST, discord_timestamp, emote, strtime

from .expire import deactivate_premium, extra_guild_perks, remind_guild_to_pay, remind_user_to_pay
from .views import DonateBtn, LegacyView


class PremiumCog(Cog, name="Premium"):
    def __init__(self, bot: DORAEMON):
        self.bot = bot
        self.remind_peeps_to_pay.start()
        self.hook = discord.Webhook.from_url(self.bot.config.PUBLIC_LOG, session=self.bot.session)

    async def ensure_premium_role(self) -> discord.Role | None:
        """Ensure the Premium role exists in the configured DORAEMON Admin server."""
        guild = self.bot.server
        if guild is None:
            print(f"[Premium] Admin server {self.bot.config.SERVER_ID} is not available to this bot.")
            return None

        role_id = int(getattr(self.bot.config, "PREMIUM_ROLE", 0) or 0)
        role = guild.get_role(role_id) if role_id else None
        if role is None:
            role = discord.utils.get(guild.roles, name="DORAEMON Premium")
        if role is None:
            me = guild.me
            if me is None or not me.guild_permissions.manage_roles:
                print("[Premium] Cannot create DORAEMON Premium role: bot needs Manage Roles.")
                return None
            try:
                role = await guild.create_role(
                    name="DORAEMON Premium",
                    permissions=discord.Permissions.none(),
                    hoist=False,
                    mentionable=False,
                    reason="Set up the DORAEMON Premium role in the configured Admin server",
                )
            except discord.HTTPException as exc:
                print(f"[Premium] Failed to create Premium role: {exc}")
                return None

        # Keep the resolved role ID available to existing purchase/claim/expiry code.
        self.bot.config.PREMIUM_ROLE = role.id
        config.PREMIUM_ROLE = role.id
        print(f"[Premium] Premium role ready in {guild.name}: {role.name} ({role.id})")
        return role

    @Cog.listener()
    async def on_ready(self):
        role = await self.ensure_premium_role()
        guild = self.bot.server
        if role is None or guild is None:
            return
        # Restore roles for users whose premium subscription is currently active.
        try:
            async for user_record in User.filter(is_premium=True):
                member = guild.get_member(user_record.user_id)
                if member is None:
                    continue
                if role not in member.roles:
                    try:
                        await member.add_roles(role, reason="Restore active DORAEMON Premium membership")
                    except discord.HTTPException as exc:
                        print(f"[Premium] Could not restore role for {member.id}: {exc}")
        except Exception as exc:
            print(f"[Premium] Role reconciliation failed: {exc}")

    @discord.app_commands.command(name="pstatus", description="Check DORAEMON Premium status")
    async def pstatus_slash(self, interaction: discord.Interaction):
        if interaction.guild is None:
            return await interaction.response.send_message("Use this command in a server.", ephemeral=True)
        guild_record = await Guild.get_or_none(pk=interaction.guild.id)
        active = bool(guild_record and guild_record.is_premium)
        end = getattr(guild_record, "premium_end_time", None) if guild_record else None
        description = "Premium is active for this server." if active else "Premium is not active for this server."
        if active and end:
            description += f"\nExpiry: {end.strftime('%d-%b-%Y %I:%M %p')}"
        embed = discord.Embed(title="DORAEMON Premium Status", description=description, color=discord.Color.gold())
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.app_commands.command(name="premium", description="View DORAEMON Premium information")
    async def premium_slash(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="💎 DORAEMON Premium",
            description=(
                "Premium includes expanded scrim and tournament limits and other premium features.\n\n"
                "Use the support server for purchase and account help."
            ),
            color=discord.Color.gold(),
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @commands.command()
    @commands.bot_has_permissions(embed_links=True)
    async def pstatus(self, ctx: Context):
        """Get your DORAEMON Premium status and the current server's."""
        guild = await Guild.filter(guild_id=ctx.guild.id).first()


        if not guild.is_premium:
            btext = "\n> Activated: No!"

        else:
            booster = guild.booster or await self.bot.fetch_user(guild.made_premium_by)
            btext = f"\n> Activated: Yes!\n> Ending: *`forever (or until Cyclone dies)`*"

        embed = self.bot.embed(ctx, title="DORAEMON Premium", url=f"{self.bot.config.WEBSITE}")
        embed.add_field(name="Server", value=btext, inline=False)
        embed.set_thumbnail(url=ctx.guild.me.display_avatar.url)
        return await ctx.send(embed=embed)

    @commands.command(aliases=("getpremium",))
    @commands.is_owner()
    @commands.bot_has_permissions(embed_links=True)
    async def prefresh(self, ctx: Context):
        """Owner-only refresh for the configured Admin server; never grants Premium to every guild."""
        admin_guild_id = int(getattr(self.bot.config, "SERVER_ID", 0) or 0)
        if ctx.guild is None or ctx.guild.id != admin_guild_id:
            return await ctx.error("This maintenance command can only be used in the configured Admin server.")

        msg = await ctx.send("🔄 Refreshing Premium status for this Admin server only...")
        end_time = datetime.utcnow() + timedelta(days=365 * 1000)
        await Guild.get_or_create(guild_id=admin_guild_id)
        await Guild.filter(pk=admin_guild_id).update(
            is_premium=True,
            premium_end_time=end_time,
            made_premium_by=self.bot.user.id
        )

        guild = await Guild.filter(guild_id=ctx.guild.id).first()

        if not guild.is_premium:
            btext = "\n> Activated: No!"
        else:
            booster = guild.booster or await self.bot.fetch_user(guild.made_premium_by)
            btext = (
                f"\n> Activated: Yes!"
                f"\n> Ending: *`forever (or until Cyclone dies)`*"
            )

        embed = self.bot.embed(ctx, title="DORAEMON Premium Refreshed", url=f"{self.bot.config.WEBSITE}")
        embed.add_field(name="Server", value=btext, inline=False)
        embed.set_thumbnail(url=ctx.guild.me.display_avatar.url)

        return await msg.edit(content=None, embed=embed)


    @commands.command(aliases=("perks", "pro"))
    async def premium(self, ctx: Context):
        """Checkout DORAEMON Premium Plans."""
        _e = discord.Embed(color=0x00FFB3)
        _e.title = "💎 Welcome to DORAEMON!"
        _e.description = (
            "__**Perks you get with DORAEMON (completely FREE!)**__\n\n"
            f"{emote.white_arrow} Access to `DORAEMON` bot.\n"
            f"{emote.white_arrow} Unlimited Scrims.\n"
            f"{emote.white_arrow} Unlimited Tournaments.\n"
            f"{emote.white_arrow} Custom Reactions for Regs.\n"
            f"{emote.white_arrow} Smart SSverification.\n"
            f"{emote.white_arrow} Cancel-Claim Panel.\n"
            f"{emote.white_arrow} Premium Role + more...\n\n"
            "_We provide this for free to honor the memory of Rohit, the original creator of DORAEMON. "
            "If you love what we do and want to support us to keep this alive, you can donate using the button below._"
        )
        _e.set_footer(text="Thank you for being part of the DORAEMON ❤️")

        v = discord.ui.View(timeout=None)
        v.add_item(DonateBtn())
        await ctx.send(embed=_e, view=v)

    @tasks.loop(hours=48)
    async def remind_peeps_to_pay(self):
        await self.bot.wait_until_ready()

        await asyncio.sleep(900)
        async for user in User.filter(is_premium=True, premium_expire_time__lte=datetime.now(tz=IST) + timedelta(days=4)):
            _u = await self.bot.getch(self.bot.get_user, self.bot.fetch_user, user.pk)
            if _u:
                if not await self.ensure_reminders(user.pk, user.premium_expire_time):
                    await self.bot.reminders.create_timer(user.premium_expire_time, "user_premium", user_id=user.pk)

                await remind_user_to_pay(_u, user)

        async for guild in Guild.filter(is_premium=True, premium_end_time__lte=datetime.now(IST) + timedelta(days=4)):
            _g = self.bot.get_guild(guild.pk)

            if not await self.ensure_reminders(guild.pk, guild.premium_end_time):
                await self.bot.reminders.create_timer(guild.premium_end_time, "guild_premium", guild_id=guild.pk)

            if _g:
                await remind_guild_to_pay(_g, guild)

    async def ensure_reminders(self, _id: int, _time: datetime) -> bool:
        return await Timer.filter(
            Q(event="guild_premium", extra={"args": [], "kwargs": {"guild_id": _id}})
            | Q(event="user_premium", extra={"args": [], "kwargs": {"user_id": _id}}),
            expires=_time,
        ).exists()

    def cog_unload(self):
        self.remind_peeps_to_pay.stop()

    @Cog.listener()
    async def on_guild_premium_timer_complete(self, timer: Timer):
        guild_id = timer.kwargs["guild_id"]

        _g = await Guild.get_or_none(pk=guild_id)
        if not _g:
            return

        if not _g.premium_end_time == timer.expires:
            return

        _perks = "\n".join(await extra_guild_perks(guild_id))

        await deactivate_premium(guild_id)

        if (_ch := _g.private_ch) and _ch.permissions_for(_ch.guild.me).embed_links:
            _e = discord.Embed(
                color=discord.Color.red(), title="⚠️__**DORAEMON Subscription Ended**__⚠️", url=config.SERVER_LINK
            )
            _e.description = (
                "This is to inform you that your subscription of DORAEMON has been ended.\n\n"
                "*Following is a list of perks or data you lost:*"
            )

            _e.description += f"```diff\n{_perks}```"

            _roles = [
                role.mention
                for role in _ch.guild.roles
                if all((role.permissions.administrator, not role.managed, role.members))
            ]

            _view = LegacyView()
            await _ch.send(
                embed=_e,
                view=_view,
                content=", ".join(_roles[:2]) if _roles else _ch.guild.owner.mention,
                allowed_mentions=discord.AllowedMentions(roles=True),
            )

    @Cog.listener()
    async def on_user_premium_timer_complete(self, timer: Timer):
        user_id = timer.kwargs["user_id"]
        _user = await User.get(pk=user_id)

        if not _user.premium_expire_time == timer.expires:
            return

        await User.filter(user_id=user_id).update(is_premium=False, premiums=0, made_premium=[])

        member = await self.bot.get_or_fetch_member(self.bot.server, _user.pk)
        if member:
            await member.remove_roles(discord.Object(id=config.PREMIUM_ROLE))

    @Cog.listener()
    async def on_premium_purchase(self, txnId: str):
        record = await PremiumTxn.get(txnid=txnId)

        member = self.bot.server.get_member(record.user_id)
        if member is not None:
            await member.add_roles(discord.Object(id=self.bot.config.PREMIUM_ROLE), reason="They purchased premium.")

        else:
            member = await self.bot.getch(self.bot.get_user, self.bot.fetch_user, record.user_id)

        with suppress(discord.HTTPException, AttributeError):
            _e = discord.Embed(
                color=discord.Color.gold(), description=f"Thanks **{member}** for purchasing DORAEMON Premium."
            )
            _e.set_image(url=random_thanks())
            await self.hook.send(embed=_e, username="premium-logs", avatar_url=self.bot.config.PREMIUM_AVATAR)

        upgraded_guild = self.bot.get_guild(record.guild_id)
        _guild = await Guild.get_or_none(pk=record.guild_id)

        _e = discord.Embed(
            color=self.bot.color,
            title="DORAEMON Purchase Successful!",
            url=self.bot.config.SERVER_LINK,
            description=(
                f"{random_greeting()} {member.mention},\n"
                f"Thanks for purchasing DORAEMON Premium. Your server **{upgraded_guild}** has access to DORAEMON features until `{_guild.premium_end_time.strftime('%d-%b-%Y %I:%M %p')}`.\n\n"
                "[Click me to Invite DORAEMON Bot to your server](https://discord.com/oauth2/authorize?client_id=902856923311919104&scope=applications.commands%20bot&permissions=21175985838)\n"
            ),
        )

        if member not in self.bot.server.members:
            _e.description += f"\n\n[To claim your Premium Role, Join DORAEMON HQ]({self.bot.config.SERVER_LINK})."

        _view = discord.ui.View(timeout=None)

        try:
            await member.send(embed=_e, view=_view)
        except discord.HTTPException:
            pass


async def setup(bot: DORAEMON) -> None:
    await bot.add_cog(PremiumCog(bot))
