from __future__ import annotations

from contextlib import suppress

import discord

from core import Context
from models import Tourney
from utils import emote, inputs
from utils import regional_indicator as ri
from utils import truncate_string

from ._base import TourneyButton

#! increase success message limit to 500
#! fake tags maybe
#! disable tourney slotm in delete


class SetTourneyname(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()
        m = await self.ctx.simple("Enter the new name of the tournament. (`Max 30 characters`)")
        name = await inputs.string_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)
        self.view.record.name = truncate_string(name, 30)

        await self.view.refresh_view()


class RegChannel(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple("Mention the channel where you want to take registrations.")
        channel = await inputs.channel_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)

        if await Tourney.filter(registration_channel_id=channel.id).exists():
            return await self.ctx.error(f"Another tourney is running in {channel.mention}.", 4)
        self.view.record.registration_channel_id = channel.id

        self.ctx.bot.cache.tourney_channels.add(channel.id)

        if not self.view.record.confirm_channel_id:
            with suppress(StopIteration, AttributeError):
                self.view.record.confirm_channel_id = next(
                    (c.id for c in channel.category.text_channels if "confirm" in c.name.lower())
                )

        if not self.view.record.role_id:
            for r in channel.guild.roles:
                if "confirm" in r.name and not await Tourney.get(role_id=r.id).exists():
                    self.view.record.role_id = r.id
                    break

        await self.view.refresh_view()


class ConfirmChannel(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple("Mention the channel where you want me to post registration confirm messages.")
        channel = await inputs.channel_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)

        self.view.record.confirm_channel_id = channel.id

        await self.view.refresh_view()


class SetRole(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple("Mention the role you want to give for correct registration.")
        role = await inputs.role_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)

        self.view.record.role_id = role.id

        await self.view.refresh_view()


class SetMentions(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple("How many mentions are required for registration? (Max `10`)")
        mentions = await inputs.integer_input(self.ctx, delete_after=True, limits=(0, 10))
        await self.ctx.safe_delete(m)

        self.view.record.required_mentions = mentions

        await self.view.refresh_view()


class MinLines(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()
        if not await self.ctx.is_premium_guild():
            return await self.ctx.error(
                "**DORAEMON Premium is required to use this feature.**\n\n`Use qpro command to activate Premium.`", 5
            )

        m = await self.ctx.simple("How many lines in registration message are required for registration? (Max `100`)")
        self.view.record.required_lines = await inputs.integer_input(self.ctx, delete_after=True, limits=(0, 10))
        await self.ctx.safe_delete(m)

        await self.view.refresh_view()


class SetPingRole(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple("Mention the role you want to ping with registration open message.")
        role = await inputs.role_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)

        self.view.record.ping_role_id = role.id

        await self.view.refresh_view()


class SetSlots(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple("How many total slots are there? (Max `15000`)")
        slots = await inputs.integer_input(self.ctx, delete_after=True, limits=(1, 15000))
        await self.ctx.safe_delete(m)

        self.view.record.total_slots = slots

        await self.view.refresh_view()


class SetEmojis(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()
        if not await self.ctx.is_premium_guild():
            return await self.ctx.error(
                "[DORAEMON Premium](https://quotientbot.xyz/premium) is required to use this feature.", 4
            )

        e = discord.Embed(color=self.ctx.bot.color, title="Edit tourney emojis")
        e.description = (
            "Which emojis do you want to use for tick and cross in tournament registrations?\n\n"
            "`Please enter two emojis and separate them with a comma`"
        )
        e.set_image(url="https://cdn.discordapp.com/attachments/851846932593770496/888097255607906354/unknown.png")
        e.set_footer(text="The first emoji must be the emoji for tick mark.")

        m = await interaction.followup.send(embed=e)
        emojis = await inputs.string_input(self.ctx, delete_after=True)

        await self.ctx.safe_delete(m)

        emojis = emojis.strip().split(",")
        if not len(emojis) == 2:
            return await interaction.followup.send("You didn't enter the correct format.", ephemeral=True)

        check, cross = emojis

        for emoji in emojis:
            try:
                await self.view.message.add_reaction(emoji.strip())
                await self.view.message.clear_reactions()
            except discord.HTTPException:
                return await interaction.followup.send("One of the emojis you entered is invalid.", ephemeral=True)

        self.view.record.emojis = {"tick": check.strip(), "cross": cross.strip()}
        await self.view.refresh_view()


class OpenRole(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple("Mention the role for which you want to open/close registrations.")
        role = await inputs.role_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)

        self.view.record.open_role_id = role.id

        await self.view.refresh_view()


class SetGroupSize(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple("How many teams will there be per group? (Max `25`)")
        n = await inputs.integer_input(self.ctx, limits=(2, 25), delete_after=True)
        await self.ctx.safe_delete(m)
        self.view.record.group_size = n
        await self.view.refresh_view()


class MultiReg(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        self.view.record.multiregister = not self.view.record.multiregister
        await self.ctx.success(
            f"Now users **{'can' if self.view.record.multiregister else 'can not'}** register more than once.", 3
        )
        await self.view.refresh_view()


class TeamCompulsion(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        self.view.record.teamname_compulsion = not self.view.record.teamname_compulsion
        await self.ctx.success(
            f"Now Team Name **{'is' if self.view.record.teamname_compulsion else 'is not'}** required to register.", 3
        )
        await self.view.refresh_view()


class DuplicateTags(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        if not await self.ctx.is_premium_guild():
            return await self.ctx.error(
                "[DORAEMON Premium](https://quotientbot.xyz/premium) is required to use this feature.", 4
            )

        self.view.record.allow_duplicate_tags = not self.view.record.allow_duplicate_tags
        await self.ctx.success(
            f"Registrations with fake / duplicate mentions are now **{'allowed' if self.view.record.allow_duplicate_tags else 'not allowed'}**.",
            3,
        )
        await self.view.refresh_view()


class DuplicateTeamName(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        self.view.record.no_duplicate_name = not self.view.record.no_duplicate_name
        await self.ctx.success(
            f"Duplicate team names are now **{'not allowed' if self.view.record.no_duplicate_name else 'allowed'}**.", 3
        )
        await self.view.refresh_view()


class AutodeleteRejected(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        self.view.record.autodelete_rejected = not self.view.record.autodelete_rejected
        await self.ctx.success(
            f"Rejected registrations will **{'be' if self.view.record.autodelete_rejected else 'not be'}** deleted automatically.",
            3,
        )
        await self.view.refresh_view()


class SuccessMessage(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple(
            "What message do you want me to show for successful registration? This message will be sent to "
            "DM of players who register successfully.\n\n**Current Success Message:**"
            f"```{self.view.record.success_message if self.view.record.success_message else 'Not Set Yet.'}```"
            "\n`Kindly keep it under 500 characters. Enter none to remove it.`",
            image="https://cdn.discordapp.com/attachments/851846932593770496/900977642382163988/unknown.png",
        )

        msg = await inputs.string_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)

        msg = truncate_string(msg, 500)
        if msg.lower().strip() == "none":
            msg = None
            await self.ctx.success("Removed Success Message.", 3)

        elif msg.lower().strip() == "cancel":
            return

        if msg != None:
            await self.ctx.success("Success Message Updated.", 3)

        self.view.record.success_message = msg
        await self.view.refresh_view()


class DeleteTourney(TourneyButton):
    def __init__(self, ctx: Context):
        super().__init__(emoji=emote.trash)

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        prompt = await self.ctx.prompt(
            "Are you sure you want to delete this tourney?\n\n`This action is not reversible.`"
        )
        if not prompt:
            return await self.ctx.simple("Okay, not deleting.", 3)

        await self.view.record.full_delete(interaction.user)
        await self.ctx.success("Successfully deleted tourney.", 3)

        from .main import TourneyManager as TM

        self.view.stop()
        v = TM(self.ctx)
        v.message = await self.view.message.edit(embed=await v.initial_embed(), view=v)


class DiscardButton(TourneyButton):
    def __init__(self, ctx: Context, label: str = "Go Back", row: int = None):
        super().__init__(label=label, style=discord.ButtonStyle.red, row=row)
        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        from .main import TourneyManager as TM

        self.view.stop()
        v = TM(self.ctx)
        v.message = await self.view.message.edit(embed=await v.initial_embed(), view=v)


class ArchiveTournamentChannels(TourneyButton):
    def __init__(self, ctx: Context):
        super().__init__(label="Keep in Past Tournament", emoji="📦", row=4)
        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        registration = self.view.record.registration_channel
        category = getattr(registration, "category", None)
        channels = list(category.channels) if category else [registration, self.view.record.confirm_channel]
        channels = [channel for channel in channels if channel is not None]
        if not channels:
            return await interaction.followup.send("No tournament channels were found.", ephemeral=True)
        selector = discord.ui.Select(
            placeholder="Select channels to keep in Past Tournament",
            min_values=1, max_values=min(25, len(channels)),
            options=[discord.SelectOption(label=channel.name[:100], value=str(channel.id)) for channel in channels[:25]],
        )
        view = discord.ui.View(timeout=60)
        view.add_item(selector)
        async def _picked(inter):
            await inter.response.defer(ephemeral=True)
            view.stop()
        selector.callback = _picked
        await interaction.followup.send("Choose the channels you want to keep.", view=view, ephemeral=True)
        await view.wait()
        if not selector.values:
            return
        guild = self.ctx.guild
        past = discord.utils.get(guild.categories, name="Past Tournament")
        if past is None:
            past = await guild.create_category("Past Tournament", reason="Archive retained tournament channels")
        moved = []
        for channel_id in selector.values:
            channel = guild.get_channel(int(channel_id))
            if channel:
                await channel.edit(category=past, reason="Admin moved channel to Past Tournament")
                moved.append(channel.mention)
        await interaction.followup.send(
            "Moved selected channels to **Past Tournament**:\n" + "\n".join(moved), ephemeral=True
        )


class EditTournamentCategory(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter), label="Edit Category")
        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()
        channel = self.view.record.registration_channel
        category = getattr(channel, "category", None)
        if category is None:
            return await self.ctx.error("The registration channel is not inside a category.", 4)
        prompt = await self.ctx.simple("Enter the new tournament category name (max 100 characters).")
        name = await inputs.string_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(prompt)
        await category.edit(name=truncate_string(name.strip(), 100), reason=f"Tournament category renamed by {interaction.user}")
        await self.ctx.success(f"Tournament category renamed to **{category.name}**.", 4)


class EditTournamentChannel(TourneyButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter), label="Edit Channel")
        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()
        registration = self.view.record.registration_channel
        category = getattr(registration, "category", None)
        channels = list(category.channels) if category else [registration, self.view.record.confirm_channel]
        channels = [channel for channel in channels if channel is not None]
        if not channels:
            return await self.ctx.error("No tournament channels were found to rename.", 4)
        options = [discord.SelectOption(label=channel.name[:100], value=str(channel.id)) for channel in channels[:25]]
        selector = discord.ui.Select(placeholder="Choose a tournament channel", options=options)
        view = discord.ui.View(timeout=45)
        view.add_item(selector)
        async def _picked(inter):
            await inter.response.defer(ephemeral=True)
            view.stop()
        selector.callback = _picked
        await interaction.followup.send("Select the channel to rename.", view=view, ephemeral=True)
        await view.wait()
        if not selector.values:
            return
        channel = self.ctx.guild.get_channel(int(selector.values[0]))
        if channel is None:
            return await interaction.followup.send("That channel no longer exists.", ephemeral=True)
        prompt = await self.ctx.simple("Enter the new channel name (max 100 characters).")
        name = await inputs.string_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(prompt)
        await channel.edit(name=truncate_string(name.strip(), 100), reason=f"Tournament channel renamed by {interaction.user}")
        await self.ctx.success(f"Channel renamed to **{channel.name}**.", 4)


class TournamentChannelPicker(discord.ui.View):
    """Let admins choose which tournament channels to create."""
    CHANNELS = {
        "registration": ("Registration Channel", "text"),
        "confirm": ("Confirm Channel", "text"),
        "info": ("Info", "text"),
        "updates": ("Updates", "text"),
        "rules": ("Rules", "text"),
        "schedule": ("Schedule", "text"),
        "roadmap": ("Roadmap", "text"),
        "how-to-register": ("How to Register", "text"),
        "tag-check": ("Tag Check", "text"),
        "help-desk": ("Help Desk", "text"),
        "query": ("Query (Voice)", "voice"),
    }

    def __init__(self, ctx, record):
        super().__init__(timeout=120)
        self.ctx, self.record = ctx, record
        self.picker = discord.ui.Select(
            placeholder="Choose the tournament channels to create",
            min_values=1, max_values=len(self.CHANNELS),
            options=[discord.SelectOption(label=label, value=key, description=("Voice channel" if kind == "voice" else "Text channel"))
                     for key, (label, kind) in self.CHANNELS.items()],
        )
        self.picker.callback = self.create_selected
        self.add_item(self.picker)

    async def create_selected(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("Only the person who opened this tournament setup can choose channels.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        guild = self.ctx.guild
        bot_member = guild.me
        if not bot_member or not bot_member.guild_permissions.manage_channels:
            return await interaction.followup.send("I need **Manage Channels** permission to create tournament channels.", ephemeral=True)
        import re
        category = None
        created = []
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=True, send_messages=False, read_message_history=True),
            bot_member: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True,
                manage_channels=True, manage_permissions=True, manage_messages=True),
        }
        try:
            tournament_slug = discord.utils.escape_markdown(self.record.name or "Tournament")[:30]
            category = await guild.create_category(f"{tournament_slug}", overwrites=overwrites,
                reason="DORAEMON tournament setup")
            for key in self.picker.values:
                slug, kind = self.CHANNELS[key]
                channel_name = f"ᯓ⌬〢{re.sub(r'[^a-z0-9-]+', '-', tournament_slug.lower()).strip('-')}-{key}"[:100]
                if kind == "voice":
                    channel = await category.create_voice_channel(name=channel_name, overwrites=overwrites,
                        reason="DORAEMON tournament setup")
                else:
                    channel = await category.create_text_channel(name=channel_name, overwrites=overwrites,
                        reason="DORAEMON tournament setup")
                created.append((key, channel))
        except discord.HTTPException as exc:
            for _, channel in reversed(created):
                try: await channel.delete(reason="Rollback incomplete DORAEMON tournament channel setup")
                except discord.HTTPException: pass
            if category:
                try: await category.delete(reason="Rollback incomplete DORAEMON tournament channel setup")
                except discord.HTTPException: pass
            return await interaction.followup.send(f"Couldn't create channels: `{type(exc).__name__}`. Check **Manage Channels** permission.", ephemeral=True)

        mentions = []
        for key, channel in created:
            mentions.append(f"• **{self.CHANNELS[key][0]}:** {channel.mention}")
            if key == "registration":
                self.record.registration_channel_id = channel.id
                self.ctx.bot.cache.tourney_channels.add(channel.id)
            elif key == "confirm":
                self.record.confirm_channel_id = channel.id
        await interaction.followup.send(f"ᯓ⌬〢Tournament name selected by user: **{category.name}**\nCreated channels:\n" + "\n".join(mentions) +
            "\n\nSet the success role, group size, and total slots before saving.", ephemeral=True)
        self.stop()


class AutoCreateTourneyChannels(TourneyButton):
    """Open a picker so admins choose the tournament channels to create."""
    def __init__(self, ctx: Context):
        super().__init__(style=discord.ButtonStyle.blurple, label="Auto-create Tournament Channels", row=0)
        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("Only the person who opened this tournament setup can use this button.", ephemeral=True)
        await interaction.response.send_message(
            "Select which tournament channels you want to create. You can choose multiple channels at once.",
            view=TournamentChannelPicker(self.ctx, self.view.record), ephemeral=True)


class SaveTourney(TourneyButton):
    def __init__(self, ctx: Context):
        super().__init__(style=discord.ButtonStyle.green, label="Save", disabled=True)
        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        message = await self.view.record.setup_slotm()
        self.view.record.slotm_channel_id = message.channel.id
        self.view.record.slotm_message_id = message.id

        await self.view.record.save()
        self.ctx.bot.loop.create_task(self.view.record.setup_logs())

        self.view.stop()

        await self.ctx.success("Successfully saved tourney.\n\n`Click start button to start registrations.`", 4)
        from .main import TourneyManager

        v = TourneyManager(self.ctx)
        v.message = await self.view.message.edit(embed=await v.initial_embed(), view=v)
