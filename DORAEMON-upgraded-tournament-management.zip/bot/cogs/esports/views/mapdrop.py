"""Admin map/drop-point editor shared by Scrims and Tournament slot sections."""
import asyncio
import discord


class MapDropButton(discord.ui.Button):
    def __init__(self, bot, channel_getter, *, row=None):
        super().__init__(label="Map / Drop Location", emoji="🗺️", style=discord.ButtonStyle.secondary, row=row)
        self.bot = bot
        self.channel_getter = channel_getter

    async def callback(self, interaction: discord.Interaction):
        if not (interaction.user.guild_permissions.manage_guild or interaction.user.guild_permissions.manage_channels):
            return await interaction.response.send_message("Only server admins can configure map drop locations.", ephemeral=True)
        channel = self.channel_getter()
        if channel is None:
            return await interaction.response.send_message("The slot channel could not be found.", ephemeral=True)
        selector = discord.ui.Select(
            placeholder="Select the game map",
            options=[discord.SelectOption(label=name, value=name) for name in ("Erangel", "Miramar", "Rondo")],
        )
        view = discord.ui.View(timeout=60)
        view.add_item(selector)
        async def _selected(inter):
            await inter.response.defer(ephemeral=True)
            view.stop()
        selector.callback = _selected
        await interaction.response.send_message("Choose the map for this slot section.", view=view, ephemeral=True)
        await view.wait()
        if not selector.values:
            return
        map_name = selector.values[0]
        await interaction.followup.send(
            f"Enter the drop location for **{map_name}** (landmark or grid coordinate, e.g. Pochinki / M4).",
            ephemeral=True,
        )
        try:
            message = await self.bot.wait_for(
                "message",
                check=lambda m: m.author.id == interaction.user.id and m.guild and m.guild.id == interaction.guild_id,
                timeout=90,
            )
        except asyncio.TimeoutError:
            return await interaction.followup.send("Timed out. No map location was saved.", ephemeral=True)
        location = message.content.strip()[:120]
        try:
            await message.delete()
        except discord.HTTPException:
            pass
        marker = f"DORAEMON_MAP_DROP: {map_name} — {location}"
        old_topic = channel.topic or ""
        lines = [line for line in old_topic.splitlines() if not line.startswith("DORAEMON_MAP_DROP:")]
        topic = "\n".join([*lines, marker])[:1024]
        try:
            await channel.edit(topic=topic, reason=f"Map drop configured by {interaction.user}")
        except discord.HTTPException:
            pass
        await channel.send(f"🗺️ **{map_name} drop location:** {location}")
        await interaction.followup.send(f"Saved **{map_name} — {location}** for {channel.mention}.", ephemeral=True)
