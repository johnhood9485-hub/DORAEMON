from __future__ import annotations

from datetime import datetime, timedelta
from random import randint

import dateparser
import discord
from discord.ext import commands

from core import Cog, Context
from models import BanLog, Guild, ReservedSlot, Scrim, BannedTeam
from utils import discord_timestamp, emote, plural


class PrefixScrims(Cog, name="Scrims"):
    """Prefix-only replacements for the former /scrims commands."""

    async def can_use(self, ctx: Context) -> bool:
        if not any((ctx.author.guild_permissions.manage_guild, Scrim.is_ignorable(ctx.author))):
            await ctx.error("You need `scrims-mod` role or `Manage Server` permission to use this command.")
            return False
        return True

    async def parse_time(self, value: str):
        parsed = dateparser.parse(
            value,
            settings={"TIMEZONE": "Asia/Kolkata", "RETURN_AS_TIMEZONE_AWARE": True},
        )
        if not parsed:
            return None
        while parsed <= self.bot.current_time:
            parsed += timedelta(days=1)
        return parsed

    @commands.command(name="create")
    @commands.bot_has_guild_permissions(manage_channels=True, manage_roles=True, manage_messages=True)
    async def create(self, ctx: Context, registration_channel: discord.TextChannel, slotlist_channel: discord.TextChannel,
                     success_role: discord.Role, required_mentions: int, total_slots: int, *, open_time: str):
        """Create a scrim. Formerly /scrims create."""
        if not await self.can_use(ctx):
            return
        if not 1 <= total_slots <= 30 or not 0 <= required_mentions <= 5:
            return await ctx.error("required_mentions must be 0-5 and total_slots must be 1-30.")
        if not await Guild.filter(pk=ctx.guild.id, is_premium=True).exists() and await Scrim.filter(guild_id=ctx.guild.id).count() >= 3:
            return await ctx.error("Non-premium servers can create up to 3 scrims.")
        if await Scrim.filter(registration_channel_id=registration_channel.id).exists():
            return await ctx.error(f"A scrim already exists in {registration_channel.mention}.")
        for channel in (registration_channel, slotlist_channel):
            perms = channel.permissions_for(ctx.me)
            if not (perms.manage_channels and perms.manage_permissions):
                return await ctx.error(f"I need channel management permissions in {channel.mention}.")
        if success_role.managed or success_role >= ctx.me.top_role or success_role >= ctx.author.top_role:
            return await ctx.error("That success role cannot be managed by me or by you.")
        if any((success_role.permissions.manage_guild, success_role.permissions.administrator,
                success_role.permissions.manage_channels, success_role.permissions.manage_roles,
                success_role.permissions.kick_members, success_role.permissions.ban_members)):
            return await ctx.error("The success role has dangerous permissions.")
        parsed = await self.parse_time(open_time)
        if not parsed:
            return await ctx.error("Invalid open time. Example: `tomorrow 7pm`.")
        autoclean_time = self.bot.current_time.replace(hour=4, minute=30, second=0, microsecond=0) + timedelta(days=1)
        scrim = Scrim(registration_channel_id=registration_channel.id, slotlist_channel_id=slotlist_channel.id,
                      role_id=success_role.id, required_mentions=required_mentions, total_slots=total_slots,
                      open_time=parsed, host_id=ctx.author.id, autoclean_time=autoclean_time, guild_id=ctx.guild.id)
        try:
            await scrim.setup_logs()
        except Exception as exc:
            return await ctx.error(f"Could not setup scrim logs: {exc}")
        await scrim.save()
        await self.bot.reminders.create_timer(scrim.open_time, "scrim_open", scrim_id=scrim.id)
        await self.bot.reminders.create_timer(scrim.autoclean_time, "autoclean", scrim_id=scrim.id)
        embed = discord.Embed(color=discord.Color.green(), title="Scrim created successfully!")
        embed.add_field(name="Registration", value=registration_channel.mention)
        embed.add_field(name="Slotlist", value=slotlist_channel.mention)
        embed.add_field(name="Success Role", value=success_role.mention)
        embed.add_field(name="Required Mentions", value=str(required_mentions))
        embed.add_field(name="Total Slots", value=str(total_slots))
        embed.add_field(name="Open Time", value=discord_timestamp(parsed, 'f'))
        embed.set_footer(text=f"Scrim ID: {scrim.id}")
        await ctx.send(embed=embed)

    @commands.command(name="reserve")
    async def reserve(self, ctx: Context, registration_channel: discord.TextChannel, slot: int, team_name: str,
                      user: discord.Member | None = None, *, expire_time: str | None = None):
        """Reserve a scrim slot."""
        if not await self.can_use(ctx):
            return
        scrim = await Scrim.get_or_none(registration_channel_id=registration_channel.id, guild_id=ctx.guild.id)
        if not scrim:
            return await ctx.error(f"No scrim found in {registration_channel.mention}.")
        if not 1 <= slot <= scrim.total_slots:
            return await ctx.error(f"Slot must be between 1 and {scrim.total_slots}.")
        expiry = None
        if expire_time:
            expiry = await self.parse_time(expire_time)
            if not expiry:
                return await ctx.error("Invalid expiry time.")
        old = await scrim.reserved_slots.filter(num=slot).first()
        if old:
            await old.delete()
        record = await ReservedSlot.create(num=slot, user_id=getattr(user, 'id', None), team_name=team_name, expires=expiry)
        await scrim.reserved_slots.add(record)
        if expiry and user:
            await self.bot.reminders.create_timer(expiry, "scrim_reserve", scrim_id=scrim.id, user_id=user.id, team_name=team_name, num=slot)
        await ctx.success(f"Slot `{slot}` reserved for **{team_name}** in {registration_channel.mention}.")

    @commands.command(name="unban")
    async def unban(self, ctx: Context, user: discord.Member, *, reason: str = "No reason given"):
        """Remove a user from all scrim bans in this server."""
        if not await self.can_use(ctx):
            return
        scrims = await Scrim.filter(guild_id=ctx.guild.id)
        changed = []
        for scrim in scrims:
            record = await scrim.banned_teams.filter(user_id=user.id).first()
            if record:
                await record.delete()
                changed.append(scrim)
        if not changed:
            return await ctx.error(f"{user.mention} is not banned from any scrim in this server.")
        banlog = await BanLog.get_or_none(guild_id=ctx.guild.id)
        if banlog:
            await banlog.log_unban(user.id, ctx.author, changed, reason)
        await ctx.success(f"{user.mention} has been unbanned from {plural(changed):scrim|scrims}.")

    @commands.command(name="slotinfo")
    async def slotinfo(self, ctx: Context, user: discord.Member):
        """Show all scrim slots owned by a user."""
        if not await self.can_use(ctx):
            return
        lines = []
        for scrim in await Scrim.filter(guild_id=ctx.guild.id):
            for slot in await scrim.assigned_slots.filter(user_id=user.id).order_by('num'):
                lines.append(f"`{slot.num:02}` **{slot.team_name or 'Unnamed'}** — {scrim.registration_channel.mention if scrim.registration_channel else 'deleted'}")
        if not lines:
            return await ctx.error(f"{user.mention} doesn't have any slot in this server's scrims.")
        embed = self.bot.embed(ctx, title=f"{user}'s scrim slots", description='\n'.join(lines))
        await ctx.send(embed=embed)

    @commands.command(name="slotlist")
    async def slotlist(self, ctx: Context, registration_channel: discord.TextChannel):
        """Post the current scrim slotlist."""
        if not await self.can_use(ctx):
            return
        scrim = await Scrim.get_or_none(registration_channel_id=registration_channel.id, guild_id=ctx.guild.id)
        if not scrim:
            return await ctx.error(f"No scrim found in {registration_channel.mention}.")
        if not await scrim.teams_registered.all():
            return await ctx.error(f"{scrim} has no registrations.")
        embed, _ = await scrim.create_slotlist()
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(PrefixScrims(bot))
