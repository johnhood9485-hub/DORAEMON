from __future__ import annotations

import json
from pathlib import Path

import discord
from discord.ext import commands

from core import Cog, Context

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "team_verifications.json"


def read_records():
    try:
        value = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        return value if isinstance(value, list) else []
    except (OSError, json.JSONDecodeError):
        return []


def save_record(record):
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    records = read_records()
    records.append(record)
    DATA_FILE.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")


class TeamVerifyModal(discord.ui.Modal, title="XT ESPORTS Team Verification"):
    team_name = discord.ui.TextInput(label="Team name", placeholder="Enter your team name", max_length=80, required=True)
    owner_email = discord.ui.TextInput(label="Owner email", placeholder="name@example.com", max_length=120, required=True)
    whatsapp = discord.ui.TextInput(label="Owner WhatsApp number", placeholder="Include country code", max_length=30, required=True)
    players = discord.ui.TextInput(
        label="Players: IGN | Discord tag (one per line)",
        placeholder="PlayerIGN | @DiscordUser\nAnotherIGN | anotheruser",
        style=discord.TextStyle.paragraph,
        max_length=1500,
        required=True,
    )

    async def on_submit(self, interaction: discord.Interaction):
        lines = [line.strip() for line in str(self.players).splitlines() if line.strip()]
        parsed = []
        for line in lines:
            if "|" not in line:
                return await interaction.response.send_message(
                    f"Invalid player line: `{discord.utils.escape_markdown(line)}`. Use `IGN | Discord tag`. Player UID is not required.",
                    ephemeral=True,
                )
            ign, tag = (part.strip() for part in line.split("|", 1))
            if not ign or not tag:
                return await interaction.response.send_message(
                    "Every player needs both an IGN and a Discord tag. Player UID is not requested.", ephemeral=True
                )
            parsed.append({"ign": ign, "discord_tag": tag})
        if not parsed:
            return await interaction.response.send_message(
                "Add at least one player with IGN and Discord tag.", ephemeral=True
            )
        record = {
            "guild_id": interaction.guild_id,
            "submitted_by": interaction.user.id,
            "team_name": str(self.team_name).strip(),
            "owner_email": str(self.owner_email).strip(),
            "whatsapp": str(self.whatsapp).strip(),
            "players": parsed,
            "status": "pending",
        }
        try:
            save_record(record)
        except OSError:
            return await interaction.response.send_message(
                "Could not save this submission. Please contact an administrator.", ephemeral=True
            )

        embed = discord.Embed(title="Team Verification Submission", color=discord.Color.orange())
        embed.add_field(name="Team", value=record["team_name"][:1024], inline=True)
        embed.add_field(name="Owner", value=interaction.user.mention, inline=True)
        embed.add_field(name="Email", value=record["owner_email"][:1024], inline=True)
        embed.add_field(name="WhatsApp", value=record["whatsapp"][:1024], inline=True)
        player_text = "\n".join(f"• {p['ign']} | {p['discord_tag']}" for p in parsed)
        embed.add_field(name="Players (IGN | Discord tag)", value=player_text[:1024], inline=False)
        embed.set_footer(text="Pending admin review • No player UID collected")
        try:
            if interaction.channel:
                await interaction.channel.send(embed=embed)
        except (discord.Forbidden, discord.HTTPException):
            pass
        await interaction.response.send_message("Your team verification was submitted for admin review.", ephemeral=True)


class TeamVerifyView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Verify Team", style=discord.ButtonStyle.primary, emoji="✅", custom_id="doraemon_teamverify:submit")
    async def verify(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(TeamVerifyModal())

    @discord.ui.button(label="Manage Team", style=discord.ButtonStyle.secondary, emoji="✏️", custom_id="doraemon_teamverify:manage")
    async def manage(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "To correct team details, submit the updated information using **Verify Team** and ask an admin to review it.",
            ephemeral=True,
        )

    @discord.ui.button(label="Manage (Admin Only)", style=discord.ButtonStyle.secondary, emoji="⚙️", custom_id="doraemon_teamverify:admin")
    async def admin(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.manage_guild:
            return await interaction.response.send_message("This button is for server administrators only.", ephemeral=True)
        records = [
            r for r in read_records()
            if r.get("guild_id") == interaction.guild_id and r.get("status") == "pending"
        ]
        await interaction.response.send_message(
            f"There are **{len(records)}** pending team verification submission(s). Records are saved in `data/team_verifications.json` on the bot host.",
            ephemeral=True,
        )


class QuScrimsView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Create", style=discord.ButtonStyle.primary, emoji="➕", custom_id="doraemon_quscrims:create")
    async def create(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Use the existing `smanager` command to create and manage scrims.", ephemeral=True)

    @discord.ui.button(label="Edit Settings", style=discord.ButtonStyle.secondary, emoji="⚙️", custom_id="doraemon_quscrims:settings")
    async def settings(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Scrim settings are managed with `smanager`; existing settings are unchanged.", ephemeral=True)

    @discord.ui.button(label="Get Data", style=discord.ButtonStyle.secondary, emoji="📋", custom_id="doraemon_quscrims:data")
    async def data(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Use `slotlist` and `slotinfo` to view existing scrim slot data.", ephemeral=True)

    @discord.ui.button(label="Enable/Disable", style=discord.ButtonStyle.success, emoji="🟢", custom_id="doraemon_quscrims:toggle")
    async def toggle(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Use the existing scrims manager to control your scrim settings. This panel does not change existing records.", ephemeral=True)

    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, emoji="🗑️", custom_id="doraemon_quscrims:delete")
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("For safety, manage deletion through the existing scrims manager; this panel will not delete data.", ephemeral=True)

    @discord.ui.button(label="Help", style=discord.ButtonStyle.secondary, emoji="❔", custom_id="doraemon_quscrims:help")
    async def help_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("This dashboard links to the existing scrims system. Use `smanager` for full scrim management.", ephemeral=True)


class TeamVerify(Cog, name="Team Verification"):
    def __init__(self, bot):
        self.bot = bot
        bot.add_view(TeamVerifyView())
        bot.add_view(QuScrimsView())

    @commands.command(name="teamverify", aliases=["verifyteam"])
    @commands.guild_only()
    async def teamverify(self, ctx: Context):
        """Post the team verification panel. Player IGN and Discord tag are required; UID is not collected."""
        embed = discord.Embed(
            title="XT ESPORTS Team Verification",
            description=(
                "Verify your team details and participate in XT ESPORTS scrims.\n\n"
                "🔴 **Requirements**\n"
                "➤ Owner details (Email, WhatsApp number)\n"
                "➤ Team details (Team name, players)\n"
                "➤ Player details (**IGN and Discord tag only; UID is not required**)\n\n"
                "Powered by DORAEMON"
            ),
            color=discord.Color.blurple(),
        )
        await ctx.send(embed=embed, view=TeamVerifyView())

    @commands.command(name="uscims", aliases=["quscrims"])
    @commands.guild_only()
    async def uscims(self, ctx: Context):
        """Post DORAEMON Ultimate Scrims dashboard. Use d+uscims (duscims) or d+quscrims."""
        embed = discord.Embed(
            title="DORAEMON Ultimate Scrims",
            description=(
                "Manage scrims using the buttons below.\n\n"
                "➕ **Create** — open the existing scrims manager\n"
                "⚙️ **Edit Settings** — manage scrim settings\n"
                "📋 **Get Data** — view existing slot data\n"
                "🟢 **Enable/Disable** — status help\n"
                "🗑️ **Delete** — safe guidance for deleting scrims"
            ),
            color=discord.Color.blurple(),
        )
        embed.set_footer(text=f"Requested by {ctx.author.display_name}")
        await ctx.send(embed=embed, view=QuScrimsView())


async def setup(bot):
    await bot.add_cog(TeamVerify(bot))
