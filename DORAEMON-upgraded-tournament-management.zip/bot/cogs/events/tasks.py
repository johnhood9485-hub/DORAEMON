from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from core import DORAEMON

from discord.ext import tasks

import config
from core import Cog


class DoraemonTasks(Cog):
    def __init__(self, bot: DORAEMON):
        self.bot = bot
        self.insert_guilds.start()

    @tasks.loop(count=1)
    async def insert_guilds(self):
        from models import Guild
        for guild in self.bot.guilds:
            await Guild.get_or_create(
                guild_id=guild.id,
                defaults={"prefix": config.PREFIX, "embed_color": config.COLOR, "embed_footer": config.FOOTER},
            )

    @insert_guilds.before_loop
    async def before_loops(self):
        await self.bot.wait_until_ready()
