#!/bin/sh
set -eu
python3 -m pip cache purge || true
python3 -m pip install --no-cache-dir -r requirements.txt
