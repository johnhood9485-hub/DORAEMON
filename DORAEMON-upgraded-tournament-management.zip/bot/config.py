"""DORAEMON configuration loaded from .env."""
import os
from pathlib import Path
from env_loader import load_env_file

load_env_file(Path(__file__).resolve().parent / ".env")

def _int(name, default=0):
    try: return int(os.getenv(name, str(default)) or default)
    except ValueError: return default

def _csv_ints(name):
    return [_int_value for _int_value in (int(x.strip()) for x in os.getenv(name, "").split(",") if x.strip())]

DB_PATH = os.getenv("DATABASE_PATH", str(Path(__file__).resolve().parent / "doraemon.db"))
TORTOISE = {
    "connections": {"default": {"engine": "tortoise.backends.sqlite", "credentials": {"file_path": DB_PATH}}},
    "apps": {"models": {"models": ["models"], "default_connection": "default"}}
}
EXTENSIONS = ["cogs.esports", "cogs.events", "cogs.mod", "cogs.premium", "cogs.doraemon_misc", "cogs.reminder", "cogs.utility", "cogs.teamverify"]
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "")
COLOR = _int("COLOR", 0x00FFB3)
FOOTER = os.getenv("FOOTER", "DORAEMON • PUBG Mobile Scrims")
PREFIX = os.getenv("PREFIX", "d")
PRIME_EMOJI = os.getenv("PRIME_EMOJI", "⚡")
OWNER_ID = os.getenv("OWNER_ID", "1508993349107847169")
DEVS = _csv_ints("DEVS")
SERVER_LINK = os.getenv("SERVER_LINK", "1508743907507179573")
SERVER_ID = _int("SERVER_ID", 1508743907507179573)
TOURNEY_CSV_CHANNEL = _int("TOURNEY_CSV_CHANNEL", 0)
EMOJIS_SERVER = _csv_ints("EMOJIS_SERVER")
BOT_INVITE = os.getenv("BOT_INVITE", "")
ACTIVITIES = [
    {"type": "playing", "name": "PUBG Mobile scrims • DORAEMON"},
    {"type": "watching", "name": "{servers} servers | {members} players"},
]
SHARD_LOG = os.getenv("SHARD_LOG", "")
ERROR_LOG = os.getenv("ERROR_LOG", "")
PUBLIC_LOG = os.getenv("PUBLIC_LOG", "")
WEBSITE = os.getenv("WEBSITE", "")
REPOSITORY = os.getenv("REPOSITORY", "")
FASTAPI_URL = os.getenv("FASTAPI_URL", "")
FASTAPI_KEY = os.getenv("FASTAPI_KEY", "")
PROXY_URI = os.getenv("PROXY_URI", "") or None

# Optional integrations. Keeping these empty disables external payment/dashboard/socket services.
PREMIUM_ROLE = _int("PREMIUM_ROLE", 0)
PREMIUM_AVATAR = os.getenv("PREMIUM_AVATAR", "")
PRO_LINK = os.getenv("PRO_LINK", BOT_INVITE)
GUILD_LOGS = os.getenv("GUILD_LOGS", "")
PAYU_KEY = os.getenv("PAYU_KEY", "")
PAYU_SALT = os.getenv("PAYU_SALT", "")
PAYU_PAYMENT_LINK = os.getenv("PAYU_PAYMENT_LINK", "")
SUCCESS_URL = os.getenv("SUCCESS_URL", "")
FAILED_URL = os.getenv("FAILED_URL", "")
SERVER_PORT = _int("SERVER_PORT", 8080)
SOCKET_URL = os.getenv("SOCKET_URL", "")
SOCKET_AUTH = os.getenv("SOCKET_AUTH", "")
VOTER_ROLE = _int("VOTER_ROLE", 0)
RILP_HEADERS = {}
RILP_PREMIUM = os.getenv("RILP_PREMIUM", "")
