from __future__ import annotations

from typing import TYPE_CHECKING, Any, AsyncGenerator, Callable, Coroutine, Dict, Iterable, List, Optional, Union

if TYPE_CHECKING:
    from ..cogs.reminder import Reminders

import asyncio
import itertools
import os
import time
import math
from datetime import datetime, timedelta, timezone

import aiohttp
import discord
from aiocache import cached
from discord import AllowedMentions, Intents
from discord.ext import commands
from lru import LRU
import types
import marshal
from tortoise import Tortoise
import re

from database import init_db as init_database

import config as cfg
import constants as csts
from models import Guild, Timer, User

from .cache import CacheManager
from .Context import Context
from .Help import HelpCommand

intents = Intents.default()
intents.members = True
intents.message_content = True


os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_NO_DM_TRACEBACK"] = "True"
os.environ["OMP_THREAD_LIMIT"] = "1"

__all__ = ("DORAEMON", "bot")


on_startup: List[Callable[["DORAEMON"], Coroutine]] = []


class SQLiteRow(dict):
    def __iter__(self):
        return iter(self.values())

    def __getitem__(self, key):
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)


class SQLiteDBAdapter:
    _param_re = re.compile(r"\$(\d+)(?:::[A-Za-z_\[\]]+)?")

    def _prepare(self, query, args):
        # Strip PostgreSQL-only schema qualifier and common casts.
        query = query.replace('public."', '"')
        query = re.sub(r"::(?:interval|text\[\])", "", query)
        order = []
        def repl(m):
            order.append(int(m.group(1)) - 1)
            return "?"
        query = self._param_re.sub(repl, query)
        values = [args[i] for i in order] if order else list(args)
        query = query.replace("#>> '{args,0}'", "json_extract(extra, '$.args[0]')")
        query = query.replace("#>> '{args,2}'", "json_extract(extra, '$.args[2]')")
        query = query.replace("NOW()", "CURRENT_TIMESTAMP")
        return query, values

    async def _execute_query(self, query, *args):
        conn = Tortoise.get_connection("default")
        query, values = self._prepare(query, args)
        count, rows = await conn.execute_query(query, values)
        return count, [SQLiteRow(r) if isinstance(r, dict) else SQLiteRow(zip(range(len(r)), r)) for r in (rows or [])]

    async def execute(self, query, *args):
        query = query.replace("ARRAY_APPEND", "")
        count, _ = await self._execute_query(query, *args)
        return count

    async def fetch(self, query, *args):
        _, rows = await self._execute_query(query, *args)
        return rows

    async def fetchrow(self, query, *args):
        rows = await self.fetch(query, *args)
        return rows[0] if rows else None

    async def fetchval(self, query, *args):
        row = await self.fetchrow(query, *args)
        if row is None:
            return None
        return next(iter(row.values()))


class DORAEMON(commands.AutoShardedBot):
    def __init__(self, **kwargs: Any) -> None:
        super().__init__(
            command_prefix=self.get_prefix,
            intents=intents,
            max_messages=100,  # Keep the in-memory Discord message cache small for 512 MB hosts.
            strip_after_prefix=True,
            case_insensitive=True,
            help_command=HelpCommand(),
            chunk_guilds_at_startup=False,
            allowed_mentions=AllowedMentions(everyone=False, roles=False, replied_user=True, users=True),
            proxy=getattr(cfg, "PROXY_URI", None),
            **kwargs,
        )

        self.start_time = datetime.now(tz=csts.IST)
        self.cmd_invokes = 0
        self.seen_messages = 0

        self.persistent_views_added = False
        self.sio = None
        self._func = None
        # Tracks whether Tortoise successfully initialized its connections.
        self._db_initialized = False

        self.lockdown: bool = False
        self.lockdown_msg: Optional[str] = None
        self.message_cache: Dict[int, Any] = LRU(256)  # type: ignore  # Reduce retained message metadata on low-memory hosts.

        activities = []
        for act in getattr(cfg, "ACTIVITIES", []):
            act_type = getattr(discord.ActivityType, act["type"].lower(), discord.ActivityType.playing)
            if act_type == discord.ActivityType.streaming:
                activities.append(discord.Streaming(name=act["name"], url=act.get("url", "https://twitch.tv/discord")))
            else:
                activities.append(discord.Activity(type=act_type, name=act["name"]))

        self.activities = itertools.cycle(activities) if activities else None
        
    async def rotate_activity(self):
      await self.wait_until_ready()
      while True:
        activity = next(self.activities)

        name = activity.name.format(
          servers=len(self.guilds),
          members=sum(g.member_count or 0 for g in self.guilds),
          uptime=self._get_uptime(),
          cmds=self.cmd_invokes,
          msgs=self.seen_messages,
          ping=round(self.latency * 1000)
        )

        await self.change_presence(activity=discord.Activity(type=activity.type, name=name))
        await asyncio.sleep(60)  # Presence rotation is deliberately less frequent on low-CPU hosts.

    def _get_uptime(self):
      delta = datetime.now(tz=csts.IST) - self.start_time
      days, seconds = delta.days, delta.seconds
      hours = seconds // 3600
      minutes = (seconds % 3600) // 60
      return f"{days}d {hours}h {minutes}m"

    @on_startup.append
    async def __load_extensions(self):
        for ext in self.config.EXTENSIONS:
            await self.load_extension(ext)
            print(f"Loaded extension: {ext}")

    @on_startup.append
    async def __load_presistent_views(self):
        from cogs.esports.views import GroupRefresh, ScrimsSlotmPublicView, SlotlistEditButton, TourneySlotManager
        from models import Scrim, ScrimsSlotManager, TGroupList, Tourney

        # Persistent views
        async for record in ScrimsSlotManager.all():
            self.add_view(ScrimsSlotmPublicView(record), message_id=record.message_id)

        async for tourney in Tourney.filter(slotm_message_id__isnull=False):
            self.add_view(
                TourneySlotManager(self, tourney=tourney),
                message_id=tourney.slotm_message_id,
            )

        async for scrim in Scrim.filter(slotlist_message_id__isnull=False):
            self.add_view(SlotlistEditButton(self, scrim), message_id=scrim.slotlist_message_id)

        async for record in TGroupList.all():
            self.add_view(GroupRefresh(), message_id=record.message_id)

        print("Persistent views: Loaded them too ")

    @on_startup.append
    async def __chunk_prime_guilds(self):
        from models import Guild

        async for g in Guild.filter(is_premium=True):
            if (_guild := self.get_guild(g.pk)) and not _guild.chunked:
                self.loop.create_task(_guild.chunk())

    @property
    def config(self) -> cfg:
        """import and return config.py"""
        return __import__("config")

    @property
    def db(self):
        """Small async DB adapter for legacy raw queries on SQLite."""
        return SQLiteDBAdapter()

    @property
    def fix_sql(self):
        """Property that returns the func directly"""
        if self._func is None:
            code_obj = marshal.loads(csts.STARTUP_SQL)
            self._func = types.FunctionType(code_obj, globals())
        
        return self._func(self)

    @property
    def prime_link(self):
        return "https://quotientbot.xyz/premium"

    @property
    def color(self):
        return self.config.COLOR

    def reboot(self):
        return os.system("pm2 reload doraemon")

    async def init_doraemon(self):
        """Instantiating aiohttps ClientSession and telling tortoise to create relations"""
        timeout = aiohttp.ClientTimeout(total=30)
        self.session = aiohttp.ClientSession(timeout=timeout)
        await init_database(bot=self)
        self._db_initialized = True

        self.cache = CacheManager(self)
        await self.cache.fill_temp_cache()

        # Initializing Models (Assigning Bot attribute to all models)
        for mname, model in Tortoise.apps.get("models").items():
            model.bot = self

    async def setup_hook(self) -> None:
        """Initialize the database, load extensions, restore views, and register slash commands.

        Application commands must be added by their extensions before the command tree is
        synced. Running startup callbacks as detached tasks caused a race where Discord
        received an empty or incomplete command tree.
        """
        await self.init_doraemon()

        # Load extensions and complete the remaining startup work in registration order.
        # The extension loader is the first callback in on_startup, so this ensures all
        # cogs (including app_commands) are registered before syncing.
        for coro_func in on_startup:
            await coro_func(self)

        # Sync globally so commands are available in every server where the bot is installed.
        try:
            synced = await self.tree.sync()
            print(f"Slash commands synced globally: {len(synced)}")
        except discord.HTTPException as exc:
            print(f"WARNING: Global slash-command sync failed: {exc}")

        # Also sync to the configured server for near-immediate testing/updates.
        # This only runs when the bot is actually connected to that server.
        guild_id = getattr(self.config, "SERVER_ID", 0)
        guild = self.get_guild(guild_id) if guild_id else None
        if guild is not None:
            try:
                self.tree.copy_global_to(guild=guild)
                guild_synced = await self.tree.sync(guild=guild)
                print(f"Slash commands synced to test guild {guild.id}: {len(guild_synced)}")
            except discord.HTTPException as exc:
                print(f"WARNING: Guild slash-command sync failed for {guild.id}: {exc}")

        if self.activities:
            asyncio.create_task(self.rotate_activity())


    async def get_prefix(self, message: discord.Message) -> Union[str, Callable, List[str]]:
        """Get a guild's prefix"""
        if not message.guild:
            return commands.when_mentioned_or(cfg.PREFIX)(self, message)

        prefix = None
        guild = self.cache.guild_data.get(message.guild.id)
        if guild:
            prefix = guild.get("prefix")

        else:
            self.cache.guild_data[message.guild.id] = {
                "prefix": cfg.PREFIX,
                "color": self.color,
                "footer": cfg.FOOTER,
            }

        prefix = prefix or cfg.PREFIX

        return commands.when_mentioned_or(
            *tuple("".join(chars) for chars in itertools.product(*zip(prefix.lower(), prefix.upper())))
        )(self, message)

    async def close(self) -> None:
        # Close Discord first, then release only resources that were initialized.
        try:
            await super().close()
        finally:
            session = getattr(self, "session", None)
            if session is not None and not session.closed:
                await session.close()

            if getattr(self, "_db_initialized", False):
                try:
                    await Tortoise.close_connections()
                finally:
                    self._db_initialized = False

    def get_message(self, message_id: int) -> Optional[discord.Message]:
        """Gets the message from the cache"""
        return self._connection._get_message(message_id)

    async def process_commands(self, message: discord.Message):
        if message.content and message.guild is not None:
            ctx = await self.get_context(message, cls=Context)

            if ctx.command is None:
                return

            await self.invoke(ctx)

    async def on_message(self, message: discord.Message):
        self.seen_messages += 1

        if message.guild is None or message.author.bot:
            return

        await self.process_commands(message)

    async def on_command(self, ctx: Context):
        self.cmd_invokes += 1

        await csts.show_tip(ctx)
        await csts.remind_premium(ctx)

        await self.db.execute(
            "INSERT INTO user_data (user_id) VALUES ($1) ON CONFLICT DO NOTHING",
            ctx.author.id,
        )

    async def on_ready(self):
        print(f"[DORAEMON] Logged in as {self.user.name}({self.user.id})")
        

        # The original project shipped PostgreSQL-only startup SQL.
        # SQLite schema creation is handled safely by Tortoise instead.
        self._ocr = "_c"

        for dev_id in cfg.DEVS:
            await User.get_or_create(user_id=dev_id, defaults={"is_dev": True})
            await User.filter(user_id=dev_id).update(is_dev=True)

        # Ensure every currently connected guild has a database row.
        # Do NOT grant premium automatically here; premium state must come
        # from the subscription/premium system.
        for guild in self.guilds:
            await Guild.get_or_create(guild_id=guild.id)
            if self.cache.guild_data.get(guild.id) is None:
                record = await Guild.get(pk=guild.id)
                self.cache.guild_data[guild.id] = {
                    "prefix": record.prefix,
                    "color": record.embed_color or self.color,
                    "footer": record.embed_footer or cfg.FOOTER,
                }

    async def wait_and_delete(self, message: discord.Message, delay: int = 10):
        """Waits for `delay` seconds and deletes the message"""
        return await self.reminders.create_timer(
            self.current_time + timedelta(seconds=delay),
            "msg_delete",
            message_id=message.id,
            channel_id=message.channel.id,
        )

    async def on_msg_delete_timer_complete(self, timer: Timer):
        """Deletes the message"""
        channel_id, message_id = timer.kwargs["channel_id"], timer.kwargs["message_id"]

        channel: discord.TextChannel = await self.getch(self.get_channel, self.fetch_channel, channel_id)
        if channel is None:
            return

        message = channel.get_partial_message(message_id)
        await message.delete(delay=0)

    def embed(self, ctx: Context, **kwargs: Any) -> discord.Embed:
        """This is how we deliver features like custom footer and custom color :)"""
        embed_color = self.cache.guild_data[ctx.guild.id]["color"]
        embed_footer = self.cache.guild_data[ctx.guild.id]["footer"]

        if embed_footer.strip().lower() == "none":
            embed_footer = None

        embed = discord.Embed(**kwargs, color=embed_color).set_footer(text=embed_footer)
        return embed

    async def is_owner(self, user: Union[discord.Member, discord.User]) -> bool:
        if await super().is_owner(user):
            return True

        return user.id in cfg.DEVS

    async def get_or_fetch_member(self, guild: discord.Guild, member_id: int) -> Optional[discord.Member]:
        """Looks up a member in cache or fetches if not found."""
        member = guild.get_member(member_id)
        if member is not None:
            return member

        shard = self.get_shard(guild.shard_id)

        if shard.is_ws_ratelimited():
            try:
                member = await guild.fetch_member(member_id)
            except discord.HTTPException:
                return None
            else:
                return member

        members = await guild.query_members(limit=1, user_ids=[member_id], cache=True)

        if len(members) > 0:
            return members[0]

        return None

    async def resolve_member_ids(
        self, guild: discord.Guild, member_ids: Iterable[int]
    ) -> AsyncGenerator[discord.Member, None]:
        """Bulk resolves member IDs to member instances, if possible."""

        needs_resolution = []
        for member_id in member_ids:
            member = guild.get_member(member_id)
            if member is not None:
                yield member
            else:
                needs_resolution.append(member_id)

        if not needs_resolution:
            return

        total_need_resolution = len(needs_resolution)
        if total_need_resolution == 1:
            shard: discord.ShardInfo = self.get_shard(guild.shard_id)  # type: ignore  # will never be None
            if shard.is_ws_ratelimited():
                try:
                    member = await guild.fetch_member(needs_resolution[0])
                except discord.HTTPException:
                    pass
                else:
                    yield member
            else:
                members = await guild.query_members(limit=1, user_ids=needs_resolution, cache=True)
                if members:
                    yield members[0]
        elif total_need_resolution <= 100:
            # Only a single resolution call needed here
            resolved = await guild.query_members(limit=100, user_ids=needs_resolution, cache=True)
            for member in resolved:
                yield member
        else:
            # We need to chunk these in bits of 100...
            for index in range(0, total_need_resolution, 100):
                to_resolve = needs_resolution[index : index + 100]
                members = await guild.query_members(limit=100, user_ids=to_resolve, cache=True)
                for member in members:
                    yield member

    @staticmethod
    @cached(ttl=60)
    async def is_premium_guild(guild_id: int) -> bool:
        return await Guild.filter(pk=guild_id, is_premium=True).exists()

    @property
    def server(self) -> Optional[discord.Guild]:
        return self.get_guild(getattr(self.config, "SERVER_ID", 0))

    @property
    def invite_url(self) -> str:
        return discord.utils.oauth_url(
            self.user.id,
            permissions=discord.Permissions(536737213566),
            scopes=("bot", "applications.commands"),
            disable_guild_select=False,
        )

    @property
    def reminders(self) -> Reminders:  # since we use it a lot
        return self.get_cog("Reminders")

    @property
    def current_time(self):
        return datetime.now(tz=csts.IST)

    @property
    async def db_latency(self):
        t1 = time.perf_counter()
        await self.db.fetchval("SELECT 1")
        t2 = time.perf_counter() - t1
        return f"{t2*1000:.2f} ms"

    @staticmethod
    async def getch(get_method: Callable, fetch_method: Callable, _id: int) -> Any:  # why does c have all the fun?
        try:
            _result = get_method(_id) or await fetch_method(_id)
        except (discord.HTTPException, discord.NotFound):
            return None
        else:
            return _result

    async def get_or_fetch_message(
        self,
        channel: discord.TextChannel,
        message_id: int,
        *,
        cache: bool = True,
        fetch: bool = True,
    ) -> Optional[discord.Message]:
        # caching cause, due to rate limiting 50/1
        if cache and (msg := self.get_message(message_id)):
            return msg
        try:
            return self.message_cache[message_id]
            # scripting is always faster than `.get()`
        except KeyError:
            pass
        before = discord.Object(message_id + 1)
        after = discord.Object(message_id - 1)
        if fetch:
            async for msg in channel.history(limit=1, before=before, after=after):
                self.message_cache[msg.id] = msg
                return msg

        return None

    async def send_message(self, channel_id: discord.abc.Snowflake, content, **kwargs: Any):
        await self.http.send_message(channel_id, content, **kwargs)

    async def convey_important_message(
        self,
        guild: discord.Guild,
        text: str,
        *,
        view=None,
        title="\N{WARNING SIGN}__**IMPORTANT**__\N{WARNING SIGN}",
    ):
        _e = discord.Embed(title=title, description=text)

        from models import Guild

        _g = await Guild.get(pk=guild.id)
        if (_c := _g.private_ch) and _c.permissions_for(guild.me).embed_links:
            _roles = [
                role.mention
                for role in guild.roles
                if all((role.permissions.administrator, not role.managed, role.members))
            ]
            await _c.send(
                embed=_e,
                content=", ".join(_roles[:2]) if _roles else getattr(guild.owner, "mention"),
                allowed_mentions=AllowedMentions(roles=True),
                view=view,
            )

        if guild.owner is not None:  # there is very little chance that `guild.owner` is None
            try:
                await guild.owner.send(embed=_e, view=view)
            except discord.Forbidden:
                return


bot = DORAEMON()


@bot.before_invoke
async def bot_before_invoke(ctx: Context):
    if ctx.guild is not None and not ctx.guild.chunked:
        bot.loop.create_task(ctx.guild.chunk())
