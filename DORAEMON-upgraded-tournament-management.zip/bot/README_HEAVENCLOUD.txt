DORAEMON - HeavenCloud SQLite / Prefix d

Database: SQLite. No separate database server is required.
Prefix: d

1. Extract so bot.py is at /home/container/bot/bot.py
2. Rename .env.example to .env
3. Put your Discord token in .env:
   DISCORD_TOKEN=YOUR_BOT_TOKEN
   PREFIX=d
   DATABASE_PATH=doraemon.db
4. Install:
   python3 -m pip cache purge
   python3 -m pip install --no-cache-dir -r requirements.txt
5. Start:
   python3 bot.py

The package uses SQLite and does not need a PostgreSQL service.
The Scrims and Esports/Tournament command code is retained.

LOW-RESOURCE HOSTING (512 MB RAM / 0.25 vCPU)
- This build reduces the Discord message cache to 100 and the internal LRU cache to 256 entries.
- Presence rotation runs once per minute to reduce needless CPU/API activity.
- Run only one bot process and do not start duplicate instances.
- Keep log files rotated and avoid running other Python apps in the same container.
- 512 MB / 0.25 vCPU is a tight target, not a guarantee; if the host kills the process for memory, upgrade to 1 GB RAM.
