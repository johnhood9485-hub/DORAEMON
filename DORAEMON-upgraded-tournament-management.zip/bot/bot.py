"""DORAEMON Discord bot entry point.

This launcher is intentionally small and defensive: it loads the project's
.env regardless of the current working directory, validates required settings,
and always closes resources cleanly when the bot exits.
"""
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

from env_loader import load_env_file

# Make imports work both when started as `python bot.py` and from the project
# directory with `python bot/bot.py`.
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

# Prefer the bot project's .env, but don't overwrite variables already supplied
# by the process manager/container.
load_env_file(BASE_DIR / ".env")

import config  # noqa: E402
from core import bot  # noqa: E402


logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
log = logging.getLogger("doraemon.launcher")


def validate_config() -> None:
    """Fail early with useful messages instead of a cryptic Discord error."""
    missing = []
    if not config.DISCORD_TOKEN.strip():
        missing.append("DISCORD_TOKEN")
    if missing:
        raise SystemExit(
            "Missing required environment variable(s): "
            + ", ".join(missing)
            + ". Add them to bot/.env or your hosting environment."
        )


def main() -> None:
    validate_config()
    log.info("Starting DORAEMON from %s", BASE_DIR)

    try:
        bot.run(config.DISCORD_TOKEN)
    except KeyboardInterrupt:
        log.info("DORAEMON stopped by user.")
    except Exception:
        log.exception("DORAEMON stopped because of an unexpected error.")
        raise


if __name__ == "__main__":
    main()
