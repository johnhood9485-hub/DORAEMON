"""Small local compatibility shim for the two ImageHash APIs DORAEMON uses.

The esports screenshot-verification code only needs to decode stored hexadecimal
hashes and compare them with Hamming distance. The full ImageHash package pulls
in NumPy/SciPy/PyWavelets, which is unnecessary on small hosts.
"""
from __future__ import annotations


class ImageHash:
    __slots__ = ("_value", "_bits")

    def __init__(self, value: int, bits: int):
        self._value = int(value)
        self._bits = int(bits)

    def __sub__(self, other: "ImageHash") -> int:
        if not isinstance(other, ImageHash):
            raise TypeError("ImageHash can only be compared with another ImageHash")
        if self._bits != other._bits:
            raise ValueError("Image hashes must have the same size")
        return (self._value ^ other._value).bit_count()

    def __str__(self) -> str:
        width = max(1, (self._bits + 3) // 4)
        return f"{self._value:0{width}x}"


def hex_to_hash(hexstr: str) -> ImageHash:
    if not isinstance(hexstr, str) or not hexstr:
        raise ValueError("Invalid hexadecimal image hash")
    value = int(hexstr, 16)
    return ImageHash(value, len(hexstr) * 4)
