DORAEMON — HeavenCloud SQLite build

Database: SQLite (doraemon.db), created automatically. No PostgreSQL server and no port 5432 are required.
Prefix: d

Required environment:
DISCORD_TOKEN=your_bot_token
DATABASE_PATH=doraemon.db

Start:
python3 bot.py

For HeavenCloud with ~715 MB storage, install without pip cache:
python3 -m pip cache purge
python3 -m pip install --no-cache-dir -r requirements.txt

Scrims and Esports/Tournament command code is retained; only the database implementation was changed from PostgreSQL arrays/raw SQL to SQLite-compatible storage.
